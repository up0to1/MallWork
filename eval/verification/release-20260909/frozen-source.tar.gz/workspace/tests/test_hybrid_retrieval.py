from unittest.mock import AsyncMock
from types import SimpleNamespace
import pytest
from app.application.usecases.catalog_search import CatalogSearchUseCase
from app.domain.catalog.product_search_spec import ProductSearchSpec
from app.domain.catalog.ports.retrieval_ports import VectorHit
from app.infrastructure.persistence.in_memory_repositories import InMemoryProductRepository
from app.infrastructure.retrieval.bm25 import bm25_rank, reciprocal_rank_fusion
from app.infrastructure.rag.category_knowledge import bootstrap_category_knowledge
from tests.test_phase3 import knowledge_base  # noqa: F401


def test_bm25_retains_exact_model_tokens_and_does_not_reward_spam():
    def product(pid, text):
        return SimpleNamespace(product_id=pid, searchable_text=lambda: text)
    products = [product("P1", "WH-1000XM5 Sony 耳机"), product("P2", "Sony " + "耳机 "*500)]
    assert bm25_rank("WH-1000XM5", products)[0][1].product_id == "P1"
    assert len(bm25_rank("不存在型号abc987", products)) == 0


def test_rrf_ignores_incomparable_raw_scores():
    a, b = SimpleNamespace(product_id="A"), SimpleNamespace(product_id="B")
    ranked = reciprocal_rank_fusion([(1000000, a), (1, b)], [(1, b)])
    assert ranked[0][1].product_id == "B"


async def test_hybrid_filters_before_lexical_cut_and_deduplicates():
    repo = InMemoryProductRepository()
    usecase = CatalogSearchUseCase(repo, hybrid_enabled=True)
    result = await usecase.execute(ProductSearchSpec(normalized_query="旅行", ship_to="US", price_max_major=100, top_k=8, excluded_material_tags=["合成聚合物"]))
    assert result["recall_strategy"] == "bm25" and not result["rerank_applied"]
    for hit in result["hits"]:
        assert hit["price_major"] <= 100 and "US" in hit["ships_to"]
        assert "合成聚合物" not in hit["material_tags"]
    ids = [h["canonical_product_id"] or h["product_id"] for h in result["hits"]]
    assert len(ids) == len(set(ids))


async def test_adaptive_vector_recall_finds_valid_candidate_below_initial_window():
    repo = InMemoryProductRepository()
    products = await repo.list_all()
    excluded = [p for p in products if p.primary_available_sku().price.to_major_units() > 1][:64]
    selected = next(p for p in products if p.product_id not in {p.product_id for p in excluded})
    # 只允许末尾商品，证明补召回确实经过统一硬约束判断。
    index = SimpleNamespace(search=AsyncMock(side_effect=lambda emb, top_n: [VectorHit(p.product_id, 1/(i+1)) for i,p in enumerate([*excluded, selected][:top_n])]))
    usecase = CatalogSearchUseCase(repo, embedder=SimpleNamespace(embed=AsyncMock(return_value=[1])), vector_index=index, hybrid_enabled=True)
    usecase._reject_reason = lambda p,s: None if p.product_id == selected.product_id else "over_price_cap"
    result = await usecase.execute(ProductSearchSpec(normalized_query="unmatchable-model-abc", top_k=1))
    assert [h["product_id"] for h in result["hits"]] == [selected.product_id]
    assert index.search.await_count == 3
    assert result["recall_strategy"] == "hybrid_only"


async def test_knowledge_same_id_update_and_deleted_file_remove_old_chunks(knowledge_base, tmp_path):
    directory = tmp_path / "knowledge"
    (directory / "outdoor.md").write_text("# 户外新版\n登山杖新版本：只引用这一段。", encoding="utf-8")
    (directory / "guide.md").unlink()
    assert await bootstrap_category_knowledge(knowledge_base, directory) == 1
    docs = await knowledge_base.list_documents()
    assert [doc.document_id for doc in docs] == ["outdoor"]
    assert docs[0].metadata["content_sha256"]
    results = await knowledge_base.search(queries=["登山杖"], top_k=4)
    content = str(results)
    assert "新版本" in content and "防水等级" not in content and "800" not in content
