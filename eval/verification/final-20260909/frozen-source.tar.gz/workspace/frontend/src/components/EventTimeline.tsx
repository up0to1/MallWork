import type { DiagnosticEvent } from "../types";
import Icon from "./Icon";
export default function EventTimeline({
  events,
}: {
  events: DiagnosticEvent[];
}) {
  return (
    <details className="diagnostics">
      <summary>
        <Icon name="clock" />
        <span>查看运行记录</span>
        <span className="diagnostic-count">{events.length}</span>
      </summary>
      <p className="diagnostic-description">
        展示可见执行步骤与状态，不包含模型隐式推理。
      </p>
      {events.length === 0 ? (
        <p className="diagnostic-empty">
          开始一次选购后，执行记录会出现在这里。
        </p>
      ) : (
        <ol>
          {events.slice(-60).map((event) => (
            <li key={event.id}>
              <div className="event-heading">
                <span>{event.label || event.type}</span>
                <time>
                  {new Date(event.timestamp).toLocaleTimeString("zh-CN", {
                    hour12: false,
                  })}
                </time>
              </div>
              <span className="event-type">{event.type}</span>
              {event.detail && <p>{event.detail}</p>}
            </li>
          ))}
        </ol>
      )}
    </details>
  );
}
