# -*- coding: utf-8 -*-
"""将真实 AgentScope 事件和业务结果投影为 AG-UI，不承担业务决策。"""
from __future__ import annotations

import copy
import json
from typing import Any, Callable

from ag_ui.core import (
    AssistantMessage,
    BaseEvent,
    CustomEvent,
    MessagesSnapshotEvent,
    RunAgentInput,
    RunErrorEvent,
    RunFinishedEvent,
    RunStartedEvent,
    StateSnapshotEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    ToolCallResultEvent,
    ToolCallStartEvent,
)

from app.infrastructure.eventbus import TradeEvent

_TOOL_LABELS = {
    "product_search_tool": "检索商品",
    "category_insight_tool": "查询选购知识",
    "web_search_tool": "核实外部资料",
    "task_dispatch": "协调专家任务",
    "remember_preference_tool": "保存购物偏好",
    "forget_preference_tool": "更新购物偏好",
    "create_order_tool": "准备订单意向",
    "query_order_tool": "查询订单",
    "cancel_order_tool": "准备取消确认",
}


class AGUIRunAdapter:
    def __init__(self, request: RunAgentInput, emit: Callable[[BaseEvent], None]) -> None:
        self.request = request
        self.emit = emit
        self.state: dict[str, Any] = {
            "products": [],
            "confirmations": [],
            "searchCompleted": False,
            "status": "queued",
            "progress": [],
        }
        self.error: str | None = None
        self._text_open: set[str] = set()
        self._tool_open: set[str] = set()
        self._tool_names: dict[str, str] = {}
        self._tool_output: dict[str, list[str]] = {}
        self._completed = False

    def _id(self, kind: str, original: str) -> str:
        return f"{self.request.run_id}:{kind}:{original}"

    def snapshot(self) -> None:
        # 队列消费者稍后才序列化，必须隔离后续原地状态修改。
        self.emit(StateSnapshotEvent(snapshot=copy.deepcopy(self.state)))

    def start(self) -> None:
        self.emit(RunStartedEvent(thread_id=self.request.thread_id, run_id=self.request.run_id))
        self.snapshot()

    def _progress(self, identifier: str, label: str, status: str) -> None:
        entries = self.state["progress"]
        entry = next((entry for entry in entries if entry["id"] == identifier), None)
        if entry is None:
            entries.append({"id": identifier, "label": label, "status": status})
        else:
            entry.update(label=label, status=status)

    def on_agent_event(self, event: Any) -> None:
        """保留框架原始的开始/增量/结束边界，不从工具名称推测调用关联。"""
        kind = getattr(event, "type", None)
        if kind == "REPLY_START":
            self.state["status"] = "running"
            self.snapshot()
        elif kind == "TEXT_BLOCK_START":
            message_id = self._id("text", event.block_id)
            self._text_open.add(message_id)
            self.emit(TextMessageStartEvent(message_id=message_id, role="assistant"))
        elif kind == "TEXT_BLOCK_DELTA":
            if event.delta:
                self.emit(TextMessageContentEvent(
                    message_id=self._id("text", event.block_id), delta=event.delta,
                ))
        elif kind == "TEXT_BLOCK_END":
            message_id = self._id("text", event.block_id)
            self._text_open.discard(message_id)
            self.emit(TextMessageEndEvent(message_id=message_id))
        elif kind == "TOOL_CALL_START":
            call_id = self._id("tool", event.tool_call_id)
            self._tool_names[event.tool_call_id] = event.tool_call_name
            self._tool_open.add(call_id)
            self.emit(ToolCallStartEvent(tool_call_id=call_id, tool_call_name=event.tool_call_name))
        elif kind == "TOOL_CALL_DELTA":
            if event.delta:
                self.emit(ToolCallArgsEvent(
                    tool_call_id=self._id("tool", event.tool_call_id), delta=event.delta,
                ))
        elif kind == "TOOL_CALL_END":
            call_id = self._id("tool", event.tool_call_id)
            self._tool_open.discard(call_id)
            # END 仅表示参数流结束；工具是否完成由 RESULT 表达。
            self.emit(ToolCallEndEvent(tool_call_id=call_id))
        elif kind == "TOOL_RESULT_START":
            name = event.tool_call_name
            self._tool_names[event.tool_call_id] = name
            self._tool_output[event.tool_call_id] = []
            self._progress(self._id("tool", event.tool_call_id), _TOOL_LABELS.get(name, name), "running")
            self.snapshot()
        elif kind == "TOOL_RESULT_TEXT_DELTA":
            self._tool_output.setdefault(event.tool_call_id, []).append(event.delta)
        elif kind == "TOOL_RESULT_DATA_DELTA":
            # 媒体结果保留其真实元数据，不在通用日志里重复传播大块 base64。
            self._tool_output.setdefault(event.tool_call_id, []).append(json.dumps({
                "media_type": event.media_type, "url": event.url,
            }, ensure_ascii=False))
        elif kind == "TOOL_RESULT_END":
            call_id = self._id("tool", event.tool_call_id)
            name = self._tool_names.get(event.tool_call_id, "工具")
            success = str(event.state).lower() == "success"
            self.emit(ToolCallResultEvent(
                message_id=self._id("result", event.tool_call_id),
                tool_call_id=call_id,
                content="".join(self._tool_output.pop(event.tool_call_id, [])),
                role="tool",
            ))
            self._progress(call_id, _TOOL_LABELS.get(name, name), "completed" if success else "error")
            self.snapshot()
        elif kind == "REPLY_END":
            reason = str(event.finished_reason).lower()
            if reason in {"error", "interrupted", "exceed_max_iters"}:
                self.error = "本轮执行未正常完成，请重试或缩小问题范围。"
        elif kind in {"REQUIRE_USER_CONFIRM", "REQUIRE_EXTERNAL_EXECUTION"}:
            # 首版不接受 resume，遇到暂停必须如实结束，不能把未执行动作展示成成功。
            self.error = "本次操作需要人工确认或外部执行，当前流式入口尚未接入此续接流程。"

    def on_trade_event(self, event: TradeEvent) -> None:
        if event.shopping_session_id != self.request.thread_id:
            return
        payload = event.payload if isinstance(event.payload, dict) else {}
        if event.type == "tool.result" and payload.get("tool") == "product_search_tool" and "hits" in payload:
            # 由检索工具的真实返回驱动商品卡；空结果也必须清除旧商品。
            self.state["products"] = copy.deepcopy(payload["hits"])
            self.state["searchCompleted"] = True
            self.snapshot()
        elif event.type in {"confirmation.required", "confirmation.resolved"}:
            confirmation = payload.get("confirmation")
            if (isinstance(confirmation, dict) and isinstance(self.request.forwarded_props, dict)
                    and confirmation.get("buyer_id") == self.request.forwarded_props.get("buyerId")
                    and confirmation.get("session_id") == self.request.thread_id):
                previous = self.state["confirmations"]
                self.state["confirmations"] = [copy.deepcopy(confirmation), *[
                    item for item in previous if item["confirmation_id"] != confirmation["confirmation_id"]
                ]][:20]
                self.snapshot()
        elif event.type == "plan.update":
            for task in payload.get("tasks", []):
                task_state = str(task.get("state", "")).lower()
                status = "completed" if task_state in {"completed", "done"} else "running"
                self._progress(f"plan:{task['id']}", task.get("subject", "任务"), status)
            self.snapshot()
        elif event.type in {"agent.dispatch", "cache.hit", "model.fallback", "context.compressed", "error"}:
            self.emit(CustomEvent(name=event.type, value=payload))

    def _close_streams(self) -> None:
        # 中断/错误时关闭已打开的消息和参数流，客户端不会残留永久 loading。
        for message_id in sorted(self._text_open):
            self.emit(TextMessageEndEvent(message_id=message_id))
        self._text_open.clear()
        for call_id in sorted(self._tool_open):
            self.emit(ToolCallEndEvent(tool_call_id=call_id))
        self._tool_open.clear()

    def finish(self, final_text: str) -> None:
        if self._completed:
            return
        self._completed = True
        self._close_streams()
        # 用审核后的最终回答收口；保留客户端传入的全部历史与本轮用户消息。
        self.emit(MessagesSnapshotEvent(messages=[
            *self.request.messages,
            AssistantMessage(id=self._id("final", "answer"), content=final_text),
        ]))
        self.state["status"] = "completed"
        self.snapshot()
        self.emit(RunFinishedEvent(thread_id=self.request.thread_id, run_id=self.request.run_id))

    def fail(self, message: str, *, cancelled: bool = False) -> None:
        if self._completed:
            return
        self._completed = True
        self._close_streams()
        self.state["status"] = "cancelled" if cancelled else "error"
        for entry in self.state["progress"]:
            if entry["status"] == "running":
                entry["status"] = "error"
        self.snapshot()
        self.emit(RunErrorEvent(message=message, code="CANCELLED" if cancelled else "AGENT_ERROR"))
